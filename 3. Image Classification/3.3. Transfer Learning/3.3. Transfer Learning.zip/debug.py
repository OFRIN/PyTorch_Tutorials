from utility.utils import csv_print

# csv_print(['Epoch','Loss', 'Accuracy'], './vgg16.csv')
csv_print([1,0.4, 0.60], './vgg16.csv')
csv_print([2,0.1, 0.60], './vgg16.csv')
csv_print([3,0.2, 0.60], './vgg16.csv')
csv_print([4,0.0, 0.60], './vgg16.csv')
csv_print([5,0.05, 0.60], './vgg16.csv')